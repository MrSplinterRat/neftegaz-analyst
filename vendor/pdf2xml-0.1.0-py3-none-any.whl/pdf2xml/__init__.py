"""pdf2xml — восстановление структуры таблиц из PDF по координатам слов.

Что делает: читает координаты слов, собирает из них строки, находит шапку,
восстанавливает МНОГОЯРУСНЫЕ заголовки колонок и привязывает каждое значение к
колонке по интервалу x. Отдаёт объекты или семантический XML.

Чего НЕ делает: не распознаёт сканы (нужен текстовый слой), не восстанавливает
объединённые ячейки внутри тела таблицы, не разбирает вложенные таблицы.

    from pdf2xml import parse_pdf, to_string

    document = parse_pdf("steo_full.pdf")
    table = document.find_table("Table 2.")
    print(table.column_labels())          # ['2025Q1', '2025Q2', ..., '2027']
    print(to_string(document))
"""

from pdf2xml.geometry import build_columns, find_header, group_lines, parse_page
from pdf2xml.model import Column, Document, Page, Row, Table, Word
from pdf2xml.parse import parse_pdf
from pdf2xml.words import DEFAULT_ENGINE, ENGINES, available_engines, read_words
from pdf2xml.xml import to_element, to_string

__version__ = "0.1.0"

__all__ = [
    "Word",
    "Column",
    "Row",
    "Table",
    "Page",
    "Document",
    "parse_pdf",
    "parse_page",
    "group_lines",
    "find_header",
    "build_columns",
    "read_words",
    "available_engines",
    "ENGINES",
    "DEFAULT_ENGINE",
    "to_element",
    "to_string",
    "__version__",
]
