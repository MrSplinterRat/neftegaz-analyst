"""Вывод разобранного документа семантическим XML.

★РАЗМЕТКА ОПИСЫВАЕТ СМЫСЛ, А НЕ ВИД. Ни ширин, ни шрифтов, ни цветов: тег
говорит, ЧТО это (таблица, ярус шапки, ячейка), а не как это выглядело. Вид —
дело слоя показа, и попади он сюда, файл пришлось бы перевыпускать при смене
оформления.

Координаты остаются атрибутами: по ним ячейку находят на исходной странице.
Это не оформление, а провенанс — без него цитата непроверяема.

Формат:

    <document path="..." engine="poppler" pages="176">
      <page number="32">
        <table caption="Table 2. Energy Prices" caption-inherited="false" width="15">
          <columns>
            <column index="0" label="2025Q1" x-lo="..." x-hi="...">
              <tier level="0">2025</tier>
              <tier level="1">Q1</tier>
            </column>
          </columns>
          <row label="Crude Oil Prices">
            <cell column="0" label="2025Q1">74.98</cell>
          </row>
        </table>
        <text>...дословный текст страницы...</text>
      </page>
    </document>

★ЯЧЕЙКА НЕСЁТ И НОМЕР КОЛОНКИ, И ЕЁ ИМЯ. Дублирование намеренное: без имени
файл нельзя прочесть без второго прохода по шапке, а без номера теряется
порядок, если имена в шапке повторяются (в отчётах STEO четыре колонки «Q1»).

★ПРОПУЩЕННЫХ ЯЧЕЕК В ВЫВОДЕ НЕТ. Отсутствие ячейки и есть «данных нет»:
изобретать для этого пустую строку значило бы добавить текст, которого на
странице не было, — прямо против первого инварианта.
"""

from __future__ import annotations

import xml.etree.ElementTree as ElementTree

from pdf2xml.model import Document, Table

__all__ = ["to_element", "to_string"]


def _table_element(table: Table) -> ElementTree.Element:
    node = ElementTree.Element(
        "table",
        {
            "caption": table.caption,
            "caption-inherited": "true" if table.caption_inherited else "false",
            "width": str(table.width),
        },
    )
    columns = ElementTree.SubElement(node, "columns")
    for index, column in enumerate(table.columns):
        column_node = ElementTree.SubElement(
            columns,
            "column",
            {
                "index": str(index),
                "label": column.label,
                "x-lo": f"{column.x_lo:.2f}",
                "x-hi": f"{column.x_hi:.2f}",
            },
        )
        for level, tier in enumerate(column.tiers):
            tier_node = ElementTree.SubElement(column_node, "tier", {"level": str(level)})
            tier_node.text = tier

    for row in table.rows:
        row_node = ElementTree.SubElement(node, "row", {"label": row.label})
        for index in sorted(row.cells):
            cell = ElementTree.SubElement(
                row_node,
                "cell",
                {
                    "column": str(index),
                    "label": table.columns[index].label if index < table.width else "",
                },
            )
            cell.text = row.cells[index]
    return node


def to_element(document: Document, with_text: bool = True) -> ElementTree.Element:
    root = ElementTree.Element(
        "document",
        {
            "path": document.path,
            "engine": document.engine,
            "pages": str(len(document.pages)),
        },
    )
    for page in document.pages:
        page_node = ElementTree.SubElement(root, "page", {"number": str(page.number)})
        for table in page.tables:
            page_node.append(_table_element(table))
        if with_text and page.words:
            text_node = ElementTree.SubElement(page_node, "text")
            text_node.text = page.text()
    return root


def to_string(document: Document, with_text: bool = True) -> str:
    root = to_element(document, with_text=with_text)
    ElementTree.indent(root, space="  ")
    return ElementTree.tostring(root, encoding="unicode", xml_declaration=True)
