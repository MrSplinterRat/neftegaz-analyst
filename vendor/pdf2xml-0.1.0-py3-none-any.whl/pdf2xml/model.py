"""Объекты документа. Всё, что библиотека знает о разобранном PDF.

★ДВА ИНВАРИАНТА, КОТОРЫЕ ДЕРЖАТ ВСЁ ОСТАЛЬНОЕ.

Первый: текст ДОСЛОВЕН. Ни одно поле не содержит текста, которого нет на
странице. Библиотека добавляет ТОЛЬКО связи между уже существующими кусками:
это значение принадлежит этой колонке, эта таблица называется так. Ссылка на
страницу обязана оставаться проверяемой, иначе разбор бесполезен ровно там,
где нужен, — в цитировании.

Второй: связь ЧИТАЕТСЯ, а не выводится из расстояний. Значение принадлежит
колонке потому, что его x-центр лежит в интервале этой колонки, а не потому,
что оно шестое по счёту. Разница видна на строке с пропусками: при счёте по
порядку всё уезжает влево и остаётся правдоподобным на вид.
"""

from __future__ import annotations

from dataclasses import dataclass, field

__all__ = ["Word", "Column", "Row", "Table", "Page", "Document"]


@dataclass(frozen=True)
class Word:
    """Слово с его прямоугольником на странице. Единица, из которой всё собрано."""

    text: str
    x0: float
    x1: float
    top: float

    @property
    def center(self) -> float:
        return (self.x0 + self.x1) / 2


@dataclass(frozen=True)
class Column:
    """Колонка таблицы: как названа и какой интервал по x занимает.

    ``tiers`` хранит ярусы шапки сверху вниз — например ``("2025", "Q1")``.
    ``label`` — их склейка, готовая к показу: ``2025Q1``.

    ★ЯРУСЫ ХРАНЯТСЯ ОТДЕЛЬНО, а не только склеенные. Потребителю бывает нужен
    именно верхний ярус (сгруппировать по годам) или именно нижний (сравнить
    кварталы между годами), и разбирать склейку обратно строкой — значит терять
    то, что уже было известно.
    """

    label: str
    tiers: tuple[str, ...]
    x_lo: float
    x_hi: float

    def holds(self, x: float) -> bool:
        return self.x_lo <= x < self.x_hi


@dataclass
class Row:
    """Строка таблицы. Ячейки РАЗРЕЖЁННЫЕ: индекс колонки → дословный текст.

    ★Разрежённость не оптимизация, а суть. Пустая ячейка в этих отчётах значит
    «данных нет» и занимает свою колонку. Храни мы плотный список без привязки
    к индексу — строка с пропусками уехала бы, и это невозможно было бы
    заметить, потому что все значения остались бы настоящими.
    """

    label: str
    cells: dict[int, str] = field(default_factory=dict)
    top: float = 0.0

    def values(self, width: int, empty: str = "") -> list[str]:
        """Плотный список по колонкам: пропуски заполнены ``empty``."""
        return [self.cells.get(index, empty) for index in range(width)]


@dataclass
class Table:
    """Таблица: заголовок, колонки, строки, номер страницы.

    ``caption_inherited`` отмечает страницу-продолжение, где заголовка нет и он
    взят с предыдущей. Признак хранится, потому что это РАЗНЫЕ утверждения:
    «заголовок прочитан здесь» и «заголовок унаследован». Второе слабее, и
    потребитель вправе знать, какое из них перед ним.
    """

    caption: str
    columns: list[Column]
    rows: list[Row]
    page: int
    caption_inherited: bool = False

    @property
    def width(self) -> int:
        return len(self.columns)

    def column_labels(self) -> list[str]:
        return [column.label for column in self.columns]


@dataclass
class Page:
    """Страница: её таблицы и все её слова.

    Слова остаются при странице намеренно. Разбор таблиц — не единственное, что
    делают с отчётом; тот, кому нужна проза, не должен разбирать PDF заново
    другим инструментом и получать другой текст.
    """

    number: int
    words: list[Word]
    tables: list[Table] = field(default_factory=list)

    def text(self) -> str:
        """Текст страницы строками, слова в порядке слева направо."""
        from pdf2xml.geometry import group_lines

        return "\n".join(
            " ".join(word.text for word in sorted(line, key=lambda w: w.x0))
            for line in group_lines(self.words)
        )


@dataclass
class Document:
    """Разобранный документ."""

    path: str
    pages: list[Page]
    engine: str

    def tables(self) -> list[Table]:
        return [table for page in self.pages for table in page.tables]

    def find_table(self, caption_part: str) -> Table | None:
        needle = caption_part.lower()
        for table in self.tables():
            if needle in table.caption.lower():
                return table
        return None
