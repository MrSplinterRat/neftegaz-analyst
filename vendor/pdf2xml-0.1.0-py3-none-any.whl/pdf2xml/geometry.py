"""Разбор таблицы из координат слов.

★ГЛАВНЫЙ ХОД: КОЛОНКА ОПРЕДЕЛЯЕТСЯ ИНТЕРВАЛОМ X, А НЕ ПОРЯДКОВЫМ НОМЕРОМ.

Готовые детекторы таблиц (camelot, tabula, встроенные find_tables) отдают
ячейки — и на этом останавливаются. Многоярусную шапку они возвращают обычной
строкой, а её ячейки садятся в произвольную колонку своей группы, причём
смещение непостоянно даже между страницами одного документа:

    camelot, стр. 32:  годы попали в колонки 2, 6, 10, 14
    camelot, стр. 35:  годы попали в колонки 3, 7, 10, 14
    tabula,  стр. 32:  кварталы в 1,2,4,5,6,7,9,10,11,12,14,15 — не подряд

Чтобы после такого узнать, какому году принадлежит квартал, пришлось бы снова
делить на группы по позиции. Это догадка — ровно то, от чего мы уходим.
Привязка по интервалу x снимает вопрос: верхний ярус накрывает те же координаты,
что и нижний, и «2025Q1» получается чтением, а не счётом.

★ВТОРОЙ ХОД: ЗАГОЛОВОК ИЩЕТСЯ ПО Y, А НЕ ПО ПОРЯДКУ В ПОТОКЕ ТЕКСТА.

Извлекатели выдают текст не в том порядке, в каком он стоит на странице. В
корпусе EIA STEO заголовок таблицы оказывается ПОСЛЕ первой строки своих данных
на 168 страницах из 208 — на странице 32 отстоит от неё на 4483 знака. Разбор,
берущий ближайший заголовок выше по потоку, подписывает строки предыдущей
таблицей; замер по корпусу дал 79% таких строк. Физически же заголовок — самая
верхняя строка страницы. Поэтому здесь он ищется как строка над шапкой с
наименьшим y, а на страницах-продолжениях наследуется.
"""

from __future__ import annotations

import re
from collections.abc import Callable

from pdf2xml.model import Column, Row, Table, Word

__all__ = [
    "Y_TOLERANCE",
    "MIN_HEADER_TOKENS",
    "VALUE",
    "CAPTION",
    "group_lines",
    "is_period",
    "find_header",
    "build_columns",
    "parse_page",
]

# Допуск по вертикали, в пунктах. Слова одной строки не стоят на одном y точно:
# надстрочные знаки и разные кегли смещают базовую линию на доли пункта.
Y_TOLERANCE = 1.6

# Сколько обозначений периода должно стоять в строке, чтобы счесть её шапкой.
# Порог высокий намеренно: пара дат встречается и в прозе, а восемь в одну
# строку ставит только таблица.
MIN_HEADER_TOKENS = 8

# Значение ячейки: число, прочерк на месте отсутствующих данных, или пометка
# вроде NA/W. ★Прочерк — ЗНАЧЕНИЕ, а не пустота: он занимает свою колонку.
VALUE = re.compile(r"^(?:-|--|NA|W|-?\d[\d,]*(?:\.\d+)?)$")

CAPTION = re.compile(r"^(?:Table|Таблица)\s+\d+[a-zа-я]?\.")

_PERIOD = re.compile(r"^(?:Q[1-4]|Year|Год|H[12]|1[89]\d{2}|20\d{2}"
                     r"|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)$", re.IGNORECASE)


def is_period(token: str) -> bool:
    """Похоже ли слово на обозначение периода — квартал, год, месяц, полугодие."""
    return bool(_PERIOD.match(token))


def group_lines(words: list[Word], tolerance: float = Y_TOLERANCE) -> list[list[Word]]:
    """Сгруппировать слова в строки по вертикали, строки — сверху вниз."""
    ordered = sorted(words, key=lambda word: (word.top, word.x0))
    lines: list[list[Word]] = []
    current: list[Word] = []
    anchor: float | None = None
    for word in ordered:
        if anchor is None or abs(word.top - anchor) <= tolerance:
            current.append(word)
            anchor = word.top if anchor is None else anchor
        else:
            lines.append(current)
            current = [word]
            anchor = word.top
    if current:
        lines.append(current)
    return lines


def find_header(
    lines: list[list[Word]],
    is_label: Callable[[str], bool] = is_period,
    minimum: int = MIN_HEADER_TOKENS,
) -> int | None:
    """Номер строки-шапки, либо None.

    Строка признаётся шапкой, если обозначений периода в ней не меньше порога
    И посторонних слов не больше двух. Второе условие обязательно: без него
    шапкой становится колонтитул, в котором есть дата выпуска.

    ``is_label`` вынесен параметром — за пределами наших отчётов столбцы
    называются не периодами, и правило подменяется, не трогая остального.
    """
    for index, line in enumerate(lines):
        tokens = [word.text for word in line]
        hits = sum(1 for token in tokens if is_label(token))
        if hits >= minimum and hits >= len(tokens) - 2:
            return index
    return None


def build_columns(header: list[Word], upper: list[Word]) -> list[Column]:
    """Колонки: имя, ярусы и интервал по x.

    Границы — середины между x-центрами соседних слов шапки. Крайние интервалы
    продлеваются наружу на половину шага, чтобы значение, выступающее за край
    своего заголовка (длинное число под коротким «Q1»), не оказалось за
    пределами всех колонок.

    Верхний ярус привязывается к колонке ПО БЛИЗОСТИ ЦЕНТРА, а не по индексу:
    полоса лет обычно центрирована над своей группой, и её слов вчетверо
    меньше, чем колонок.
    """
    header = sorted(header, key=lambda word: word.x0)
    if not header:
        return []
    centers = [word.center for word in header]
    bounds = [(centers[i] + centers[i + 1]) / 2 for i in range(len(centers) - 1)]
    step = (bounds[0] - centers[0]) if bounds else 1.0
    edges = [centers[0] - step, *bounds, centers[-1] + step]

    columns = []
    for index, word in enumerate(header):
        tiers: tuple[str, ...] = (word.text,)
        if upper:
            nearest = min(upper, key=lambda candidate: abs(candidate.center - word.center))
            # «Year» — подпись самой полосы, а не период: она называет группу
            # годовых колонок, и приклеивать её к «2025» значило бы получить
            # «Year2025» там, где на странице стоит просто «2025».
            if nearest.text not in ("Year", "Год"):
                tiers = (nearest.text, word.text)
        columns.append(
            Column(
                label="".join(tiers),
                tiers=tiers,
                x_lo=edges[index],
                x_hi=edges[index + 1],
            )
        )
    return columns


def _upper_tier(lines: list[list[Word]], header_index: int) -> list[Word]:
    """Слова яруса над шапкой, годные в названия групп."""
    if header_index == 0:
        return []
    return [
        word
        for word in lines[header_index - 1]
        if is_period(word.text) or word.text in ("Year", "Год")
    ]


def _caption_above(lines: list[list[Word]], header_index: int) -> str:
    """Заголовок таблицы: строка «Table N.» выше шапки, самая верхняя из них."""
    for line in lines[:header_index]:
        text = " ".join(word.text for word in sorted(line, key=lambda w: w.x0))
        if CAPTION.match(text):
            return text
    return ""


def parse_page(
    words: list[Word],
    page_number: int,
    inherited_caption: str = "",
) -> Table | None:
    """Разобрать одну страницу. None — таблицы на ней нет."""
    lines = group_lines(words)
    header_index = find_header(lines)
    if header_index is None:
        return None

    columns = build_columns(lines[header_index], _upper_tier(lines, header_index))
    if not columns:
        return None

    own = _caption_above(lines, header_index)
    caption = own or inherited_caption
    left_edge = columns[0].x_lo

    rows = []
    # ★СТРОКИ ТЕЛА ИЩУТСЯ ТОЛЬКО НИЖЕ ШАПКИ. Выше неё лежит полоса верхнего
    # яруса — «2025 2026 2027», — и по форме она неотличима от строки данных:
    # подпись плюс три числа. Взятая как данные, она даёт строку «Year» со
    # значениями, которых в таблице нет.
    for line in lines[header_index + 1:]:
        ordered = sorted(line, key=lambda word: word.x0)
        # ★Всё левее первой колонки — часть подписи, даже если похоже на
        # значение. Без этого дефис внутри подписи вида «(millions - SAAR)»
        # становится ячейкой и сдвигает строку.
        values = [word for word in ordered if VALUE.match(word.text) and word.center >= left_edge]
        if len(values) < 3:
            continue
        taken = {id(word) for word in values}
        label = " ".join(word.text for word in ordered if id(word) not in taken).strip(" .")
        cells: dict[int, str] = {}
        for word in values:
            for position, column in enumerate(columns):
                if column.holds(word.center):
                    cells[position] = word.text
                    break
        rows.append(Row(label=label, cells=cells, top=ordered[0].top))

    return Table(
        caption=caption,
        columns=columns,
        rows=rows,
        page=page_number,
        caption_inherited=not own and bool(inherited_caption),
    )
