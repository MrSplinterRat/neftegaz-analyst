"""Разбор документа целиком: страницы, таблицы, наследование заголовка."""

from __future__ import annotations

from pdf2xml.geometry import parse_page
from pdf2xml.model import Document, Page
from pdf2xml.words import DEFAULT_ENGINE, read_words

__all__ = ["parse_pdf"]


def parse_pdf(path: str, engine: str = DEFAULT_ENGINE, keep_words: bool = True) -> Document:
    """Разобрать PDF.

    ★Заголовок НАСЛЕДУЕТСЯ ТОЛЬКО ЧЕРЕЗ СМЕЖНУЮ СТРАНИЦУ С ТАБЛИЦЕЙ. Страница
    без таблицы — обычно диаграмма или проза — обрывает наследование. Иначе
    заголовок перепрыгивает через двадцать страниц прозы и подписывает собой
    таблицу, к которой отношения не имеет; в корпусе STEO такие прыжки дают
    основную долю ошибочных подписей.

    ``keep_words=False`` выбрасывает слова после разбора. Для восьми отчётов
    STEO это разница между 210 МБ и 12 МБ в памяти; нужно, когда индексируют
    каталог, а не читают один документ.
    """
    pages: list[Page] = []
    inherited = ""
    for number, words in enumerate(read_words(path, engine), start=1):
        table = parse_page(words, number, inherited)
        inherited = table.caption if table else ""
        page = Page(
            number=number,
            words=words if keep_words else [],
            tables=[table] if table else [],
        )
        pages.append(page)
    return Document(path=path, pages=pages, engine=engine)
