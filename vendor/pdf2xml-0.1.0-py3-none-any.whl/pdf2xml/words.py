"""Движки координат: откуда берутся слова с их прямоугольниками.

Три движка, один результат. Проверено на восьми отчётах EIA STEO: 101 тысяча
ячеек, расхождений между движками ноль. Поэтому выбор движка — вопрос цены и
лицензии, а не точности.

    poppler     /bin/pdftotext -bbox-layout   ~5 МБ, часто уже в системе, GPL-бинарь
    pdfplumber  page.extract_words()          +57 МБ, MIT, чистый питон
    pymupdf     page.get_text("words")        +64 МБ, AGPL-3.0 — только осознанно

★УМОЛЧАНИЕ — POPPLER, и не из-за скорости. Он вызывается отдельным процессом,
то есть его лицензия не смешивается с нашей, а в контейнер едет бинарник на
несколько мегабайт вместо колеса на шестьдесят. Скорость (в пятнадцать раз
быстрее pdfplumber) тут приятная добавка, а не довод.
"""

from __future__ import annotations

import shutil
import subprocess
import xml.etree.ElementTree as ElementTree
from collections.abc import Iterator

from pdf2xml.model import Word

__all__ = ["ENGINES", "DEFAULT_ENGINE", "read_words", "available_engines"]

DEFAULT_ENGINE = "poppler"
_XHTML = "{http://www.w3.org/1999/xhtml}"


def _poppler(path: str) -> Iterator[list[Word]]:
    binary = shutil.which("pdftotext") or "/bin/pdftotext"
    result = subprocess.run(
        [binary, "-bbox-layout", path, "-"],
        capture_output=True,
        check=True,
    )
    for page in ElementTree.fromstring(result.stdout).iter(_XHTML + "page"):
        yield [
            Word(word.text or "", float(word.get("xMin")), float(word.get("xMax")), float(word.get("yMin")))
            for word in page.iter(_XHTML + "word")
        ]


def _pdfplumber(path: str) -> Iterator[list[Word]]:
    import pdfplumber

    with pdfplumber.open(path) as document:
        for page in document.pages:
            yield [
                Word(word["text"], word["x0"], word["x1"], word["top"])
                for word in page.extract_words(use_text_flow=False)
            ]
            # Без сброса кэша страницы pdfplumber держит в памяти весь документ.
            page.flush_cache()


def _pymupdf(path: str) -> Iterator[list[Word]]:
    import pymupdf

    for page in pymupdf.open(path):
        yield [Word(w[4], w[0], w[2], w[1]) for w in page.get_text("words")]


ENGINES = {"poppler": _poppler, "pdfplumber": _pdfplumber, "pymupdf": _pymupdf}


def available_engines() -> list[str]:
    """Какие движки реально доступны здесь и сейчас.

    Проверка настоящая, а не по списку установленных пакетов: poppler может
    стоять в системе без питоновской обёртки, а импорт колеса — упасть на
    несовместимой версии. Отвечать по списку значило бы обещать движок,
    который не запустится.
    """
    ready = []
    if shutil.which("pdftotext") or shutil.os.path.exists("/bin/pdftotext"):
        ready.append("poppler")
    for name, module in (("pdfplumber", "pdfplumber"), ("pymupdf", "pymupdf")):
        try:
            __import__(module)
        except Exception:  # noqa: BLE001 — не установлен, это законный исход
            continue
        ready.append(name)
    return ready


def read_words(path: str, engine: str = DEFAULT_ENGINE) -> Iterator[list[Word]]:
    """Слова каждой страницы, по странице за раз."""
    if engine not in ENGINES:
        raise ValueError(f"неизвестный движок {engine!r}; есть: {', '.join(ENGINES)}")
    return ENGINES[engine](path)
