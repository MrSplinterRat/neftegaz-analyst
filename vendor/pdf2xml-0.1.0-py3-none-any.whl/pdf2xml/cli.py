"""Командная строка: pdf2xml FILE.pdf [-o OUT.xml]"""

from __future__ import annotations

import argparse
import sys

from pdf2xml.parse import parse_pdf
from pdf2xml.words import DEFAULT_ENGINE, available_engines
from pdf2xml.xml import to_string


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="pdf2xml", description=__doc__)
    parser.add_argument("path", nargs="?", help="исходный PDF")
    parser.add_argument("-o", "--out", help="куда писать XML (по умолчанию stdout)")
    parser.add_argument("-e", "--engine", default=DEFAULT_ENGINE, help="движок координат")
    parser.add_argument("--no-text", action="store_true", help="без дословного текста страниц")
    parser.add_argument("--tables", action="store_true", help="сводка по таблицам вместо XML")
    parser.add_argument("--engines", action="store_true", help="показать доступные движки")
    args = parser.parse_args(argv)

    if args.engines:
        print(" ".join(available_engines()))
        return 0
    if not args.path:
        parser.error("нужен путь к PDF")

    document = parse_pdf(args.path, engine=args.engine, keep_words=not args.no_text)

    if args.tables:
        for table in document.tables():
            mark = " (заголовок унаследован)" if table.caption_inherited else ""
            print(f"стр. {table.page}: {table.caption or '(без заголовка)'}{mark}")
            print(f"  колонок {table.width}, строк {len(table.rows)}")
            print(f"  {' '.join(table.column_labels())}")
        return 0

    text = to_string(document, with_text=not args.no_text)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(text)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
